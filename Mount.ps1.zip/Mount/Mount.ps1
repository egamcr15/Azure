﻿Configuration Mount
{
    Node localhost 
    {
       Import-DscResource -ModuleName xDisk 
       
       xWaitforDisk Disk2
       {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
       }
 
       xDisk Disk2
       {
            DiskNumber = 2
            DriveLetter= 'G'
       }    

       LocalConfigurationManager 
       {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
       }
    }
}